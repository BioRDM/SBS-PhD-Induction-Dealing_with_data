# mEos4b project folder

## Contents description

This folder contains raw data and materials for the mEos4b project.

## Authors

Daniel Thedie (daniel.thedie@ed.ac.uk)
My Supervisor (my.supervisor@ed.ac.uk)

## Folder contents

- Figures
    - Figures for presentations and articles (.png and .svg)
- Presentations
    - Presentations related to the project (.pptx)
- Raw_data
    - The raw data from in-vitro experiments and simulations (.xlsx)
- Writing
    - Written materials about the project (.docx)
- Readme.txt: this readme file

## Naming conventions

- Abs: absorbance
- norm: normalised data
- Ens: ensemble-level data
- SM: Single-Molecule data
- SM_sim: Single-Molecule simulations

