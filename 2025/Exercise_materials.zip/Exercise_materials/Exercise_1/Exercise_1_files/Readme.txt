# mEos4b project folder

## Contents description



## Authors



## Folder contents



## Naming conventions



